//
//  ViewController.swift
//  WatchTest
//
//  Created by Jagdeep Kaur  on 2019-04-06.
//  Copyright © 2019 Jagdeep Kaur . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}


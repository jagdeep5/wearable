//
//  LogicFile.swift
//  WatchTest WatchKit Extension
//
//  Created by Jagdeep Kaur  on 2019-04-06.
//  Copyright © 2019 Jagdeep Kaur . All rights reserved.
//

import WatchKit

class LogicFile: WKInterfaceController {
  
    
}

//
//  MainScreenController.swift
//  WatchTest WatchKit Extension
//
//  Created by Jagdeep Kaur  on 2019-04-06.
//  Copyright © 2019 Jagdeep Kaur . All rights reserved.
//

import UIKit
import WatchKit

class MainScreenController: WKInterfaceController {

    @IBOutlet weak var NameLabel: WKInterfaceLabel!
    var Lives: Int!
    override func willActivate() {
        super.willActivate()
        let sharedPreferences = UserDefaults.standard
        var Names = sharedPreferences.string(forKey: "name")
        
        // update the name
        self.NameLabel.setText("Hi \(Names!)")
      
    }
   
    
    @IBAction func btnEasy() {
        Lives = 6
        self.presentController(withName: "interfaceScreen", context: Lives)
       
    }
    
    @IBAction func btnHard() {
        Lives = 4
         self.presentController(withName: "interfaceScreen", context: Lives)
        
    }
}

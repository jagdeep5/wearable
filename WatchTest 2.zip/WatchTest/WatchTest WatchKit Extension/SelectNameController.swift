//
//  SelectNameController.swift
//  WatchTest WatchKit Extension
//
//  Created by Jagdeep Kaur  on 2019-04-06.
//  Copyright © 2019 Jagdeep Kaur . All rights reserved.
//

import UIKit
import WatchKit
class SelectNameController: WKInterfaceController {
    
    let sharedPreferences = UserDefaults.standard
    @IBAction func replyButtonClicked() {
        print("Buttton clicked")
        let suggestionList = ["jagdeep", "rajdeep", "harman", "mandeep"]
        presentTextInputController(withSuggestions: suggestionList, allowedInputMode: .plain){
            (results) in
            
            
            if (results != nil && results!.count > 0) {
                let userResponse = results?.first as! String
                self.sharedPreferences.set(userResponse, forKey: "name")
                self.sharedPreferences.synchronize()
                print(self.sharedPreferences.string(forKey: "name")!)
                self.pushController(withName: "mainScreen", context: nil)
            }
            
        }
       
    }
    override func willActivate() {
        
        sharedPreferences.string(forKey: "name")
        print("Saved to shared preferences!")
        self.presentController(withName: "mainScreen", context: nil)
    }
    
    
    
}
